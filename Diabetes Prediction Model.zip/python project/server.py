from flask import Flask, request, jsonify
from flask_cors import CORS
import torch
import pickle
import numpy as np
import torch.nn as nn


# Define the DiabetesModel class (same as used during training)
class DiabetesModel(nn.Module):
    def __init__(self, input_size):
        super(DiabetesModel, self).__init__()
        self.linear = nn.Linear(input_size, 1)  # Linear regression

    def forward(self, x):
        return self.linear(x)


# Load trained model and scaler
with open("diabetes_model.pkl", "rb") as f:
    model = pickle.load(f)

with open("scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend communication

# Encoding mapping for categorical features
gender_map = {"male": 0, "female": 1}


def preprocess_input(data):
    """Convert categorical variables to numerical and scale input data correctly."""
    processed_features = []

    for value in data:
        if isinstance(value, str):
            if value.lower() in gender_map:
                processed_features.append(gender_map[value.lower()])
            elif "/" in value:  # Convert "150/90" BP to two separate values
                bp_values = value.split("/")
                processed_features.extend([float(bp_values[0]), float(bp_values[1])])
            else:
                try:
                    processed_features.append(float(value))
                except ValueError:
                    processed_features.append(0.0)
        else:
            processed_features.append(value)

    # 🚀 Ensure the input has exactly 10 features
    while len(processed_features) < 10:
        processed_features.append(0.0)  # Add zero-padding if missing features

    print("🚀 Unscaled Features:", processed_features)

    processed_features = np.array(processed_features).reshape(1, -1)
    scaled_features = scaler.transform(processed_features)

    print("📊 Scaled Features:", scaled_features)

    return scaled_features


@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        print("Received Data:", data)  # Debugging

        # Preprocess input (handle categorical data)
        processed_features = preprocess_input(data['features'])



        # Convert to tensor
        input_tensor = torch.tensor(processed_features, dtype=torch.float32)


        # Make prediction
        prediction = model(input_tensor).item()
        print("📊 Prediction:", prediction)

        return jsonify({"prediction": prediction})

    except Exception as e:
        print(f"❌ Error: {e}")
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)
